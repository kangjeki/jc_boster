<div class="sidebar" mode="fixed">
	<div class="nav">
		<a class="nav-link spa-model" load="index.php" inner-id="#content" mode="sync"><i class="fas fa-rss-square"></i> Home</a>
		<a class="nav-link spa-model expand" expand-target="#data-component"><i class="fas fa-rss-square"></i> Expand Menu</a>
		<div class="expand-group" id="data-component">
			<a class="nav-link spa-model" load="..." inner-id="#content" mode="async">Menu Expand 1</a>
			<a class="nav-link spa-model" load="..." inner-id="#content" mode="async">Menu Expand 1</a>
		</div>
		<a class="nav-link spa-model" load="..." inner-id="#content" mode="async"><i class="fas fa-rss-square"></i> Menu</a>
		<a class="nav-link spa-model" href="..." target="_blank"><i class="fas fa-rss-square"></i> Menu</a>
	</div>
</div>
