<div class="footer-container">
	<div class="block-licence">
		JC Boster Web Component | Author : JC_Programs
	</div>
</div>