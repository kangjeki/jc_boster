<?php  

function get_header($title) {
	require 'include/constructor/header.php';
}
function get_header_box() {
	require 'include/constructor/header_box.php';
}
function get_sidebar() {
	require 'include/constructor/sidebar.php';
}
function get_sidebar_php_library() {
	require 'include/constructor/sidebar_php_library.php';
}
function get_footer_container() {
	require 'include/constructor/footer_container.php';
}
function get_footer() {
	require 'include/constructor/footer.php';
}

?>